function convertIP() {
    const ip = document.getElementById("ipInput").value.trim();
    const output = document.getElementById("binaryOutput");
    const status = document.getElementById("status");

    if (ip === "") {
        output.textContent = "Binary IP will appear here";
        status.textContent = "";
        return;
    }

    const octets = ip.split(".");

    if (octets.length !== 4) {
        showError();
        return;
    }

    let binaryIP = [];

    for (let octet of octets) {
        if (!isValidOctet(octet)) {
            showError();
            return;
        }
        binaryIP.push(
            parseInt(octet).toString(2).padStart(8, "0")
        );
    }

    output.textContent = binaryIP.join(".");
    status.textContent = "Valid IPv4 address ✔";
    status.style.color = "green";
}

function isValidOctet(o) {
    return /^\d+$/.test(o) && Number(o) >= 0 && Number(o) <= 255;
}

function showError() {
    document.getElementById("binaryOutput").textContent = "Invalid IPv4 address ❌";
    document.getElementById("status").textContent = "";
}

function copyBinary() {
    const text = document.getElementById("binaryOutput").textContent;
    if (text.includes(".")) {
        navigator.clipboard.writeText(text);
        document.getElementById("status").textContent = "Copied to clipboard 📋";
        document.getElementById("status").style.color = "green";
    }
}

function clearAll() {
    document.getElementById("ipInput").value = "";
    document.getElementById("binaryOutput").textContent = "Binary IP will appear here";
    document.getElementById("status").textContent = "";
}
