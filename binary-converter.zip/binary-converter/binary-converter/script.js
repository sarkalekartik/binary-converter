function convert() {
    const input = document.getElementById("inputValue").value.trim();
    const mode = document.querySelector('input[name="mode"]:checked').value;
    const resultDiv = document.getElementById("result");
    const status = document.getElementById("status");

    if (input === "") {
        status.textContent = "Please enter a number!";
        status.style.color = "red";
        return;
    }

    try {
        let result;

        if (mode === "dtb") {
            if (isNaN(input)) throw "Invalid Decimal";
            result = parseInt(input).toString(2);
            resultDiv.textContent = "Binary: " + result;
        } else {
            if (!/^[01]+$/.test(input)) throw "Invalid Binary";
            result = parseInt(input, 2);
            resultDiv.textContent = "Decimal: " + result;
        }

        status.textContent = "Conversion successful ✔";
        status.style.color = "green";

    } catch {
        resultDiv.textContent = "Result will appear here";
        status.textContent = "Invalid input ❌";
        status.style.color = "red";
    }
}

function clearAll() {
    document.getElementById("inputValue").value = "";
    document.getElementById("result").textContent = "Result will appear here";
    document.getElementById("status").textContent = "Cleared";
    document.getElementById("status").style.color = "blue";
}

function copyResult() {
    const result = document.getElementById("result").textContent;

    if (result.includes(":")) {
        navigator.clipboard.writeText(result);
        document.getElementById("status").textContent = "Copied to clipboard 📋";
        document.getElementById("status").style.color = "green";
    }
}

// Enter key support
document.getElementById("inputValue").addEventListener("keypress", function(e) {
    if (e.key === "Enter") convert();
});
