function switchType(){
  const type=document.getElementById("ipType").value;
  document.getElementById("ipv4Section").style.display =
    type==="ipv4" ? "block" : "none";
  document.getElementById("ipv6Section").style.display =
    type==="ipv6" ? "block" : "none";
}

/* ---------------- IPv4 ---------------- */

function calculateIPv4(){
  const ip=document.getElementById("ipv4").value;
  const cidr=parseInt(document.getElementById("cidr4").value);
  if(!validIPv4(ip)||cidr<0||cidr>32) return alert("Invalid IPv4");

  const mask=cidrToSubnet(cidr);
  document.getElementById("v4binary").textContent=ipToBinary(ip);
  document.getElementById("subnet").textContent=mask.join(".");
  document.getElementById("network").textContent=calcNetwork(ip,mask).join(".");
  document.getElementById("broadcast").textContent=calcBroadcast(ip,mask).join(".");
}

function validIPv4(ip){
  return ip.split(".").length===4 &&
  ip.split(".").every(o=>o>=0&&o<=255);
}

function ipToBinary(ip){
  return ip.split(".")
  .map(o=>parseInt(o).toString(2).padStart(8,"0"))
  .join(".");
}

function cidrToSubnet(c){
  let m=[];
  for(let i=0;i<4;i++){
    let bits=Math.min(8,c);
    m.push(256-Math.pow(2,8-bits));
    c-=bits;
  }
  return m;
}

function calcNetwork(ip,mask){
  return ip.split(".").map((o,i)=>o & mask[i]);
}

function calcBroadcast(ip,mask){
  return ip.split(".").map((o,i)=>
    (o & mask[i]) | (255-mask[i])
  );
}

/* ---------------- IPv6 ---------------- */

function calculateIPv6(){
  const ip=document.getElementById("ipv6").value;
  const prefix=document.getElementById("prefix6").value;
  if(!ip.includes(":")) return alert("Invalid IPv6");

  const expanded=expandIPv6(ip);
  document.getElementById("expanded").textContent=expanded;
  document.getElementById("compressed").textContent=compressIPv6(expanded);
  document.getElementById("binary6").textContent=ipv6ToBinary(expanded);

  if(prefix)
    document.getElementById("prefixInfo").textContent=
    `/`+prefix+` → Network bits: ${prefix}, Host bits: ${128-prefix}`;
}

function expandIPv6(ip){
  let p=ip.split("::");
  let l=p[0]?p[0].split(":"):[];
  let r=p[1]?p[1].split(":"):[];
  let fill=Array(8-l.length-r.length).fill("0000");
  return [...l,...fill,...r].map(x=>x.padStart(4,"0")).join(":");
}

function compressIPv6(ip){
  return ip.replace(/(^|:)0{1,3}/g,"$1").replace(/(:0)+:/,"::");
}

function ipv6ToBinary(ip){
  return ip.split(":")
  .map(h=>parseInt(h,16).toString(2).padStart(16,"0"))
  .join(" ");
}
